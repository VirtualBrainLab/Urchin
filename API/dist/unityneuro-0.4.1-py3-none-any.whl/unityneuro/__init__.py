"""
unityneuro.

Python library for connecting to and sending data to a Unity Renderer for Neuroscience client.
"""
__author__ = 'Daniel Birman'
